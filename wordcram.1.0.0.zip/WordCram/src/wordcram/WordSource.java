package wordcram;

public interface WordSource {
  public Word[] getWords();
}
