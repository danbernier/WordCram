package wordcram.text;

public interface TextSource {
    public String getText();
}
